package net.nvsoftware.springmono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmonoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmonoApplication.class, args);
	}

}
