package net.nvsoftware.springmono;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmonoApplicationTests {

	@Test
	void contextLoads() {
	}

}
